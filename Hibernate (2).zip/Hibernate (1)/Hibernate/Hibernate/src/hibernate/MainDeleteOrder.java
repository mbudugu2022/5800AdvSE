package hibernate;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import java.util.Date;


public class MainDeleteOrder {public static void main(String[] args) {

    // create session factory
    SessionFactory factory = new Configuration()
            .configure("hibernate.cfg.xml")
            .addAnnotatedClass(Order.class)
            .addAnnotatedClass(Product.class)
            .buildSessionFactory();

    // create session
    Session session = factory.getCurrentSession();

    try {
        // start a transaction
        session.beginTransaction();
// get the order from database
        int orderId = 2;
        Order tempOrder = session.get(Order.class, orderId);

        System.out.println("\nLoaded order: " + tempOrder);
        System.out.println("Courses: " + tempOrder.getProducts());

         //delete order
        System.out.println("\nDeleting order: " + tempOrder);
        session.delete(tempOrder);

        // commit transaction
        session.getTransaction().commit();

        System.out.println("Done!");
    }
    finally {
        // add clean up code
        session.close();

        factory.close();
    }
}
}
