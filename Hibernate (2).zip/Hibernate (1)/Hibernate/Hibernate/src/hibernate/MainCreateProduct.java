package hibernate;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import java.util.Date;


public class MainCreateProduct {public static void main(String[] args) {

    // create session factory
    SessionFactory factory = new Configuration()
            .configure("hibernate.cfg.xml")
            .addAnnotatedClass(Order.class)
            .addAnnotatedClass(Product.class)
            .buildSessionFactory();

    // create session
    Session session = factory.getCurrentSession();

    try {
        // start a transaction
        session.beginTransaction();
        // create a product
        Date date = new Date();
        Product Product_1 = new Product("Book");

        // save the product
        System.out.println("\nSaving the Product ...");
        session.save(Product_1);
        System.out.println("Saved the product: " + Product_1);

        Order Order_1 = new Order("John",date);
        Order Order_2 = new Order("Madhurima",date);

        Product_1.addOrder(Order_1);
        Product_1.addOrder(Order_2);

        System.out.println("\nSaving orders ...");
        session.save(tempOrder1);
        session.save(tempOrder2);
        System.out.println("Saved orders: " + Product_1.getOrders());

        // commit transaction
        session.getTransaction().commit();

        System.out.println("Done!");
    }
    finally {
        // add clean up code
        session.close();

        factory.close();
    }
}
}
