package hibernate;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import java.util.Date;


public class MainCreateOrder {public static void main(String[] args) {

		// create session factory
    SessionFactory factory = new Configuration()
            .configure("hibernate.cfg.xml")
            .addAnnotatedClass(Order.class)
            .addAnnotatedClass(Product.class)
            .buildSessionFactory();

    // create session
Session session = factory.getCurrentSession();

		try {
			// start a transaction
			session.beginTransaction();
			// create a order
            Date date = new Date();
			Order tempOrder = new Order("Madhu",date);

			// save the order
			System.out.println("\nSaving the Order ...");
			session.save(tempOrder);
			System.out.println("Saved the order: " + tempOrder);

			Product tempProduct1 = new Product("Book");
			Product tempProduct2 = new Product("Pen");

			tempOrder.addProduct(tempProduct1);
			tempOrder.addProduct(tempProduct2);

			System.out.println("\nSaving products ...");
			session.save(tempProduct1);
			session.save(tempProduct2);
			System.out.println("Saved products: " + tempOrder.getProducts());

			// commit transaction
			session.getTransaction().commit();

			System.out.println("Done!");
		}
		finally {
			// add clean up code
			session.close();

			factory.close();
		}
	}
}
