package hibernate;

import org.hibernate.*;
import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import  org.hibernate.Session.*;

@Entity
@Table(name="\"order\"")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private int id;
    @Column(name="date")
    private Date date;
    @Column(name="customer_name")
    private String customer_name;

    @ManyToMany (cascade = {CascadeType.PERSIST})
    @JoinTable(
            name="order_detail",
            joinColumns =@JoinColumn(name="order_id"),
            inverseJoinColumns = @JoinColumn(name="product_id")
    )
    private List<Product> products;

    public Order() {

    }
    public Order(String customer_name, Date date) {
        this.date = date;
        this.customer_name=customer_name;
    }

    public void addProduct(Product product) {

        if (products == null) {
            products = new ArrayList<>();
        }

        products.add(product);
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public int getId() {
        return id;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public String getCustomer_name() {
        return customer_name;
    }
    
    public void setDate(Date date) {
        this.date = date;
    }

    
    public Date getDate() {

        return date;
    }

    public List<Product> getProducts() {
        return products;
    }

   
}
