package hibernate;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import java.util.Date;


public class MainDeleteProduct {public static void main(String[] args) {

    // create session factory
    SessionFactory factory = new Configuration()
            .configure("hibernate.cfg.xml")
            .addAnnotatedClass(Order.class)
            .addAnnotatedClass(Product.class)
            .buildSessionFactory();

    // create session
    Session session = factory.getCurrentSession();

    try {
        // start a transaction
        session.beginTransaction();
// get the product from database
        int productId = 2;
        Product Product_1 = session.get(Product.class, productId);

        System.out.println("\nLoaded order: " + Product_1);
        System.out.println("Courses: " + Product_1.getOrders());

        //delete product
        System.out.println("\nDeleting order: " + Product_1);
        session.delete(Product_1);

        // commit transaction
        session.getTransaction().commit();

        System.out.println("Done!");
    }
    finally {
        // add clean up code
        session.close();

        factory.close();
    }
}
}
