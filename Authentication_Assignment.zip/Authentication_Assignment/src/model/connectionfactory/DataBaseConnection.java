package model.connectionfactory;

import java.sql.Connection;
import java.sql.SQLException;

public interface DataBaseConnection {
    Connection getDataBaseConnection() throws ClassNotFoundException, SQLException;
}
